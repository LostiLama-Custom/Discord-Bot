import fs from 'node:fs';
import path from 'node:path';

const FILE = path.resolve(process.cwd(), 'data.json');

const defaults = { guilds: {}, channels: {} };
let data = structuredClone(defaults);

function load() {
  try {
    if (fs.existsSync(FILE)) {
      data = { ...structuredClone(defaults), ...JSON.parse(fs.readFileSync(FILE, 'utf8')) };
      data.guilds ??= {};
      data.channels ??= {};
    }
  } catch (err) {
    console.error('Could not read data.json, starting with empty storage:', err);
  }
}

function save() {
  const tmp = `${FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, FILE);
}

load();

export const store = {
  getGuild(guildId) {
    return data.guilds[guildId] ?? null;
  },
  setGuild(guildId, value) {
    data.guilds[guildId] = value;
    save();
  },
  getChannel(channelId) {
    return data.channels[channelId] ?? null;
  },
  setChannel(channelId, value) {
    data.channels[channelId] = value;
    save();
  },
  patchChannel(channelId, patch) {
    if (!data.channels[channelId]) return null;
    data.channels[channelId] = { ...data.channels[channelId], ...patch };
    save();
    return data.channels[channelId];
  },
  deleteChannel(channelId) {
    delete data.channels[channelId];
    save();
  },
  allChannels() {
    return Object.entries(data.channels);
  }
};
