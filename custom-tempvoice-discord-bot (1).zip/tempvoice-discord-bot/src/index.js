import 'dotenv/config';
import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  GatewayIntentBits,
  MessageFlags,
  ModalBuilder,
  PermissionFlagsBits,
  REST,
  Routes,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
  UserSelectMenuBuilder,
} from 'discord.js';
import { store } from './store.js';

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const DEV_GUILD_ID = process.env.DEV_GUILD_ID || null;

if (!TOKEN || !CLIENT_ID) {
  console.error('Missing DISCORD_TOKEN or CLIENT_ID in .env');
  process.exit(1);
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates],
});

const commands = [
  new SlashCommandBuilder()
    .setName('tempvoice')
    .setDescription('Configure the TempVoice system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s =>
      s.setName('setup').setDescription('Create or repair the TempVoice lobby/category')
    )
    .addSubcommand(s =>
      s.setName('info').setDescription('Show the current TempVoice configuration')
    ),
].map(c => c.toJSON());

function channelRecord(channelId) {
  return store.getChannel(channelId);
}

function isOwner(interaction, rec) {
  return rec?.ownerId && interaction.user.id === rec.ownerId;
}

function ownerMention(rec) {
  return rec?.ownerId ? `<@${rec.ownerId}>` : 'Niemand – Besitz kann übernommen werden';
}

function statusText(rec) {
  const game = rec.game?.trim();
  const status = rec.status?.trim();
  if (game && status) return `🎮 ${game} • ${status}`.slice(0, 500);
  if (game) return `🎮 ${game}`.slice(0, 500);
  if (status) return status.slice(0, 500);
  return null;
}

function panelComponents(rec) {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tv:settings').setLabel('Einstellungen').setEmoji('⚙️').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('tv:lock').setLabel(rec.locked ? 'Entsperren' : 'Sperren').setEmoji(rec.locked ? '🔓' : '🔒').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv:hide').setLabel(rec.hidden ? 'Sichtbar' : 'Verstecken').setEmoji(rec.hidden ? '👁️' : '🙈').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tv:region').setLabel('Region').setEmoji('🌍').setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tv:allow').setLabel('Nutzer erlauben').setEmoji('✅').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('tv:deny').setLabel('Nutzer ablehnen').setEmoji('⛔').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('tv:text').setLabel(rec.textChannelId ? 'Text löschen' : 'Text erstellen').setEmoji('💬').setStyle(ButtonStyle.Secondary),
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tv:nsfw').setLabel(rec.nsfw ? 'NSFW aus' : 'NSFW an').setEmoji('🔞').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tv:owner')
      .setLabel(rec.ownerId ? 'Besitz übertragen' : 'Besitz übernehmen')
      .setEmoji('👑')
      .setStyle(rec.ownerId ? ButtonStyle.Secondary : ButtonStyle.Success),
  );

  return [row1, row2, row3];
}

function panelEmbed(channel, rec) {
  return new EmbedBuilder()
    .setTitle('🎛️ Voice Control')
    .setDescription('Nur der aktuelle Besitzer kann Einstellungen ändern. Verlässt der Besitzer den Voice, wird der Besitz freigegeben.')
    .addFields(
      { name: 'Besitzer', value: ownerMention(rec), inline: true },
      { name: 'Limit', value: channel.userLimit ? String(channel.userLimit) : '∞', inline: true },
      { name: 'Bitrate', value: `${Math.round(channel.bitrate / 1000)} kbps`, inline: true },
      { name: 'Spiel', value: rec.game || '—', inline: true },
      { name: 'Status', value: rec.status || '—', inline: true },
      { name: 'Region', value: channel.rtcRegion || 'Automatisch', inline: true },
      { name: 'Zugang', value: rec.locked ? '🔒 Gesperrt' : '🔓 Offen', inline: true },
      { name: 'Sichtbarkeit', value: rec.hidden ? '🙈 Versteckt' : '👁️ Sichtbar', inline: true },
      { name: 'Temp-Text', value: rec.textChannelId ? `<#${rec.textChannelId}>` : 'Aus', inline: true },
      { name: 'NSFW', value: rec.nsfw ? 'An' : 'Aus', inline: true },
    )
    .setFooter({ text: 'Der Kanal wird automatisch gelöscht, sobald er leer ist.' });
}

async function updatePanel(channelId) {
  const rec = channelRecord(channelId);
  if (!rec) return;
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel?.isVoiceBased()) return;

  const payload = { embeds: [panelEmbed(channel, rec)], components: panelComponents(rec) };
  let msg = rec.panelMessageId
    ? await channel.messages.fetch(rec.panelMessageId).catch(() => null)
    : null;

  if (msg) {
    await msg.edit(payload).catch(console.error);
  } else {
    msg = await channel.send(payload).catch(() => null);
    if (msg) store.patchChannel(channelId, { panelMessageId: msg.id });
  }
}

async function setVoiceStatus(channelId, rec) {
  await client.rest.put(Routes.channelVoiceStatus(channelId), {
    body: { status: statusText(rec) },
  });
}

function voicePermissionValue(channel, targetId, bit) {
  const ow = channel.permissionOverwrites.cache.get(targetId);
  if (!ow) return null;
  if (ow.allow.has(bit)) return true;
  if (ow.deny.has(bit)) return false;
  return null;
}

async function syncTempText(channel, rec) {
  if (!rec.textChannelId) return;
  const text = await channel.guild.channels.fetch(rec.textChannelId).catch(() => null);
  if (!text || text.type !== ChannelType.GuildText) {
    store.patchChannel(channel.id, { textChannelId: null });
    return;
  }

  const everyone = channel.guild.roles.everyone.id;
  const ids = new Set([everyone, rec.ownerId, ...channel.permissionOverwrites.cache.keys()].filter(Boolean));
  const overwrites = [];

  for (const id of ids) {
    const view = id === rec.ownerId ? true : voicePermissionValue(channel, id, PermissionFlagsBits.ViewChannel);
    const isEveryone = id === everyone;
    overwrites.push({
      id,
      allow: [
        ...(view === true ? [PermissionFlagsBits.ViewChannel] : []),
        ...(!isEveryone && view !== false ? [PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] : []),
      ],
      deny: [
        ...(view === false ? [PermissionFlagsBits.ViewChannel] : []),
      ],
    });
  }

  await text.permissionOverwrites.set(overwrites, 'Sync TempVoice permissions').catch(console.error);
}

async function createTempText(channel, rec) {
  if (rec.textChannelId) return;
  const text = await channel.guild.channels.create({
    name: `💬-${channel.name}`.slice(0, 100),
    type: ChannelType.GuildText,
    parent: channel.parentId,
    topic: `Temporärer Textkanal für <#${channel.id}>`,
    reason: 'TempVoice owner enabled temporary text channel',
  });
  store.patchChannel(channel.id, { textChannelId: text.id });
  await syncTempText(channel, store.getChannel(channel.id));
  await text.send(`💬 Temporärer Textkanal für <#${channel.id}>. Er wird zusammen mit dem Voice gelöscht.`).catch(() => {});
}

async function deleteTempText(rec) {
  if (!rec?.textChannelId) return;
  const text = await client.channels.fetch(rec.textChannelId).catch(() => null);
  if (text) await text.delete('TempVoice text disabled/deleted').catch(() => {});
}

async function cleanupTempChannel(channelId) {
  const rec = channelRecord(channelId);
  if (!rec) return;
  await deleteTempText(rec);
  store.deleteChannel(channelId);
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (channel) await channel.delete('TempVoice channel empty').catch(() => {});
}

async function createTempVoice(member, lobby) {
  const guild = member.guild;
  const config = store.getGuild(guild.id);
  if (!config) return;

  const baseName = `${member.displayName}'s Voice`.slice(0, 100);
  const channel = await guild.channels.create({
    name: baseName,
    type: ChannelType.GuildVoice,
    parent: config.categoryId || lobby.parentId,
    permissionOverwrites: [
      {
        id: guild.roles.everyone.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
      {
        id: member.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
    ],
    reason: `TempVoice created for ${member.user.tag}`,
  });

  store.setChannel(channel.id, {
    guildId: guild.id,
    ownerId: member.id,
    panelMessageId: null,
    textChannelId: null,
    locked: false,
    hidden: false,
    nsfw: false,
    game: '',
    status: '',
  });

  try {
    await member.voice.setChannel(channel, 'Join-to-create TempVoice');
  } catch (err) {
    await cleanupTempChannel(channel.id);
    throw err;
  }

  await updatePanel(channel.id);
}

async function ensureOwner(interaction, rec) {
  if (!rec) {
    await interaction.reply({ content: '❌ Dieser Kanal wird nicht vom TempVoice-Bot verwaltet.', flags: MessageFlags.Ephemeral });
    return false;
  }
  if (!isOwner(interaction, rec)) {
    await interaction.reply({ content: rec.ownerId ? `❌ Nur <@${rec.ownerId}> darf diesen Kanal ändern.` : '❌ Der Kanal hat aktuell keinen Besitzer. Nutze **Besitz übernehmen**.', flags: MessageFlags.Ephemeral });
    return false;
  }
  return true;
}

async function handleSetup(interaction) {
  const guild = interaction.guild;
  let config = store.getGuild(guild.id);
  let category = config?.categoryId ? await guild.channels.fetch(config.categoryId).catch(() => null) : null;
  let lobby = config?.lobbyId ? await guild.channels.fetch(config.lobbyId).catch(() => null) : null;

  if (!category || category.type !== ChannelType.GuildCategory) {
    category = await guild.channels.create({ name: 'TEMP VOICE', type: ChannelType.GuildCategory });
  }
  if (!lobby || lobby.type !== ChannelType.GuildVoice) {
    lobby = await guild.channels.create({
      name: '➕ Create Voice',
      type: ChannelType.GuildVoice,
      parent: category.id,
      userLimit: 0,
    });
  }

  config = { categoryId: category.id, lobbyId: lobby.id };
  store.setGuild(guild.id, config);
  await interaction.reply({ content: `✅ TempVoice ist eingerichtet. Join einfach <#${lobby.id}>.`, flags: MessageFlags.Ephemeral });
}

function settingsModal(channel, rec) {
  const modal = new ModalBuilder().setCustomId('tv:settings-modal').setTitle('Voice Einstellungen');

  const name = new TextInputBuilder().setCustomId('name').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100).setValue(channel.name);
  const limit = new TextInputBuilder().setCustomId('limit').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(2).setValue(String(channel.userLimit ?? 0));
  const game = new TextInputBuilder().setCustomId('game').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100).setValue(rec.game || '');
  const status = new TextInputBuilder().setCustomId('status').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(350).setValue(rec.status || '');
  const bitrate = new TextInputBuilder().setCustomId('bitrate').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(3).setValue(String(Math.round(channel.bitrate / 1000)));

  modal.addComponents(
    new ActionRowBuilder().addComponents(name),
    new ActionRowBuilder().addComponents(limit),
    new ActionRowBuilder().addComponents(game),
    new ActionRowBuilder().addComponents(status),
    new ActionRowBuilder().addComponents(bitrate),
  );
  return modal;
}

async function handleButton(interaction) {
  const channel = interaction.channel;
  const rec = channelRecord(channel.id);
  if (!rec) return interaction.reply({ content: '❌ Kein verwalteter TempVoice-Kanal.', flags: MessageFlags.Ephemeral });

  if (interaction.customId === 'tv:owner') {
    if (!rec.ownerId) {
      if (!channel.members.has(interaction.user.id)) {
        return interaction.reply({ content: '❌ Du musst im Voice sein, um den Besitz zu übernehmen.', flags: MessageFlags.Ephemeral });
      }
      store.patchChannel(channel.id, { ownerId: interaction.user.id });
      await syncTempText(channel, store.getChannel(channel.id));
      await updatePanel(channel.id);
      return interaction.reply({ content: '👑 Du bist jetzt Besitzer des Channels.', flags: MessageFlags.Ephemeral });
    }
    if (!(await ensureOwner(interaction, rec))) return;
    const select = new UserSelectMenuBuilder().setCustomId('tv:owner-select').setPlaceholder('Neuen Besitzer auswählen').setMinValues(1).setMaxValues(1);
    return interaction.reply({ content: 'Wähle den neuen Besitzer:', components: [new ActionRowBuilder().addComponents(select)], flags: MessageFlags.Ephemeral });
  }

  if (!(await ensureOwner(interaction, rec))) return;

  switch (interaction.customId) {
    case 'tv:settings':
      return interaction.showModal(settingsModal(channel, rec));

    case 'tv:lock': {
      const locked = !rec.locked;
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { Connect: locked ? false : null }, { reason: 'TempVoice lock toggle' });
      store.patchChannel(channel.id, { locked });
      await syncTempText(channel, store.getChannel(channel.id));
      await updatePanel(channel.id);
      return interaction.reply({ content: locked ? '🔒 Kanal gesperrt.' : '🔓 Kanal entsperrt.', flags: MessageFlags.Ephemeral });
    }

    case 'tv:hide': {
      const hidden = !rec.hidden;
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { ViewChannel: hidden ? false : null }, { reason: 'TempVoice visibility toggle' });
      await channel.permissionOverwrites.edit(interaction.user.id, { ViewChannel: true, Connect: true });
      store.patchChannel(channel.id, { hidden });
      await syncTempText(channel, store.getChannel(channel.id));
      await updatePanel(channel.id);
      return interaction.reply({ content: hidden ? '🙈 Kanal versteckt.' : '👁️ Kanal wieder sichtbar.', flags: MessageFlags.Ephemeral });
    }

    case 'tv:allow': {
      const select = new UserSelectMenuBuilder().setCustomId('tv:allow-select').setPlaceholder('Nutzer auswählen').setMinValues(1).setMaxValues(10);
      return interaction.reply({ content: 'Diese Nutzer dürfen den Kanal sehen/betreten:', components: [new ActionRowBuilder().addComponents(select)], flags: MessageFlags.Ephemeral });
    }

    case 'tv:deny': {
      const select = new UserSelectMenuBuilder().setCustomId('tv:deny-select').setPlaceholder('Nutzer auswählen').setMinValues(1).setMaxValues(10);
      return interaction.reply({ content: 'Diese Nutzer werden für den Kanal abgelehnt:', components: [new ActionRowBuilder().addComponents(select)], flags: MessageFlags.Ephemeral });
    }

    case 'tv:text': {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const latest = channelRecord(channel.id);
      if (latest.textChannelId) {
        await deleteTempText(latest);
        store.patchChannel(channel.id, { textChannelId: null });
        await updatePanel(channel.id);
        return interaction.editReply('🗑️ Temporärer Textkanal gelöscht.');
      }
      await createTempText(channel, latest);
      await updatePanel(channel.id);
      return interaction.editReply(`💬 Temporärer Textkanal erstellt: <#${store.getChannel(channel.id).textChannelId}>`);
    }

    case 'tv:nsfw': {
      const nsfw = !rec.nsfw;
      await channel.setNSFW(nsfw, 'TempVoice NSFW toggle');
      store.patchChannel(channel.id, { nsfw });
      const latest = store.getChannel(channel.id);
      if (latest.textChannelId) {
        const text = await interaction.guild.channels.fetch(latest.textChannelId).catch(() => null);
        if (text?.type === ChannelType.GuildText) await text.setNSFW(nsfw).catch(() => {});
      }
      await updatePanel(channel.id);
      return interaction.reply({ content: `🔞 NSFW ist jetzt **${nsfw ? 'an' : 'aus'}**.`, flags: MessageFlags.Ephemeral });
    }

    case 'tv:region': {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const regions = await client.rest.get(Routes.voiceRegions()).catch(() => []);
      const options = [
        { label: 'Automatisch', value: 'auto', description: 'Discord wählt die optimale Region' },
        ...regions.filter(r => !r.deprecated).slice(0, 24).map(r => ({ label: r.name.slice(0, 100), value: r.id, description: r.custom ? 'Custom Region' : (r.optimal ? 'Von Discord als optimal markiert' : undefined) })),
      ];
      const menu = new StringSelectMenuBuilder().setCustomId('tv:region-select').setPlaceholder('Voice-Region auswählen').addOptions(options);
      return interaction.editReply({ content: '🌍 Region auswählen:', components: [new ActionRowBuilder().addComponents(menu)] });
    }
  }
}

async function handleUserSelect(interaction) {
  const channel = interaction.channel;
  const rec = channelRecord(channel.id);
  if (!(await ensureOwner(interaction, rec))) return;

  if (interaction.customId === 'tv:allow-select') {
    for (const id of interaction.values) {
      await channel.permissionOverwrites.edit(id, { ViewChannel: true, Connect: true }, { reason: 'TempVoice allow user' });
    }
    await syncTempText(channel, store.getChannel(channel.id));
    await updatePanel(channel.id);
    return interaction.update({ content: `✅ ${interaction.values.map(id => `<@${id}>`).join(', ')} erlaubt.`, components: [] });
  }

  if (interaction.customId === 'tv:deny-select') {
    for (const id of interaction.values) {
      if (id === rec.ownerId) continue;
      await channel.permissionOverwrites.edit(id, { Connect: false }, { reason: 'TempVoice deny user' });
      const member = channel.members.get(id);
      if (member) await member.voice.disconnect('Denied from TempVoice').catch(() => {});
    }
    await syncTempText(channel, store.getChannel(channel.id));
    await updatePanel(channel.id);
    return interaction.update({ content: `⛔ Auswahl abgelehnt.`, components: [] });
  }

  if (interaction.customId === 'tv:owner-select') {
    const newOwnerId = interaction.values[0];
    if (!channel.members.has(newOwnerId)) {
      return interaction.update({ content: '❌ Der neue Besitzer muss aktuell im Voice-Channel sein.', components: [] });
    }
    const oldOwnerId = rec.ownerId;
    store.patchChannel(channel.id, { ownerId: newOwnerId });
    if (oldOwnerId && oldOwnerId !== newOwnerId) {
      await channel.permissionOverwrites.delete(oldOwnerId, 'TempVoice ownership transferred').catch(() => {});
    }
    await channel.permissionOverwrites.edit(newOwnerId, { ViewChannel: true, Connect: true });
    await syncTempText(channel, store.getChannel(channel.id));
    await updatePanel(channel.id);
    return interaction.update({ content: `👑 Besitz an <@${newOwnerId}> übertragen.`, components: [] });
  }
}

async function handleStringSelect(interaction) {
  const channel = interaction.channel;
  const rec = channelRecord(channel.id);
  if (!(await ensureOwner(interaction, rec))) return;

  if (interaction.customId === 'tv:region-select') {
    const value = interaction.values[0];
    await channel.setRTCRegion(value === 'auto' ? null : value, 'TempVoice region change');
    await updatePanel(channel.id);
    return interaction.update({ content: `🌍 Region: **${value === 'auto' ? 'Automatisch' : value}**`, components: [] });
  }
}

async function handleSettingsModal(interaction) {
  const channel = interaction.channel;
  const rec = channelRecord(channel.id);
  if (!(await ensureOwner(interaction, rec))) return;

  const name = interaction.fields.getTextInputValue('name').trim();
  const limitRaw = interaction.fields.getTextInputValue('limit').trim();
  const game = interaction.fields.getTextInputValue('game').trim();
  const status = interaction.fields.getTextInputValue('status').trim();
  const bitrateRaw = interaction.fields.getTextInputValue('bitrate').trim();

  const limit = Number(limitRaw);
  const bitrateKbps = Number(bitrateRaw);
  const maxKbps = Math.floor((interaction.guild.maximumBitrate ?? 96000) / 1000);

  if (!name || !Number.isInteger(limit) || limit < 0 || limit > 99) {
    return interaction.reply({ content: '❌ Name darf nicht leer sein und Nutzerlimit muss eine ganze Zahl von 0–99 sein.', flags: MessageFlags.Ephemeral });
  }
  if (!Number.isInteger(bitrateKbps) || bitrateKbps < 8 || bitrateKbps > maxKbps) {
    return interaction.reply({ content: `❌ Bitrate muss zwischen **8 und ${maxKbps} kbps** liegen (Server-/Boost-Limit).`, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  await channel.edit({ name, userLimit: limit, bitrate: bitrateKbps * 1000 }, 'TempVoice settings');
  const latest = store.patchChannel(channel.id, { game, status });
  await setVoiceStatus(channel.id, latest).catch(err => console.error('Could not set voice status:', err));

  if (latest.textChannelId) {
    const text = await interaction.guild.channels.fetch(latest.textChannelId).catch(() => null);
    if (text?.type === ChannelType.GuildText) await text.setName(`💬-${name}`.slice(0, 100)).catch(() => {});
  }

  await updatePanel(channel.id);
  return interaction.editReply('✅ Einstellungen gespeichert.');
}

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);

  const rest = new REST({ version: '10' }).setToken(TOKEN);
  if (DEV_GUILD_ID) {
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, DEV_GUILD_ID), { body: commands });
    console.log(`Registered guild commands for ${DEV_GUILD_ID}`);
  } else {
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
    console.log('Registered global commands');
  }

  // Repair/clean persisted channels after restarts.
  for (const [channelId, rec] of store.allChannels()) {
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel?.isVoiceBased()) {
      await deleteTempText(rec);
      store.deleteChannel(channelId);
      continue;
    }
    if (channel.members.size === 0) {
      await cleanupTempChannel(channelId);
      continue;
    }
    if (rec.ownerId && !channel.members.has(rec.ownerId)) {
      store.patchChannel(channelId, { ownerId: null });
    }
    await updatePanel(channelId);
  }
});

client.on('voiceStateUpdate', async (oldState, newState) => {
  try {
    const guild = newState.guild ?? oldState.guild;
    const config = store.getGuild(guild.id);

    if (config && newState.channelId === config.lobbyId && oldState.channelId !== config.lobbyId && newState.member && !newState.member.user.bot) {
      await createTempVoice(newState.member, newState.channel);
    }

    if (oldState.channelId && oldState.channelId !== newState.channelId) {
      const rec = channelRecord(oldState.channelId);
      if (rec) {
        const oldChannel = await guild.channels.fetch(oldState.channelId).catch(() => null);
        if (!oldChannel?.isVoiceBased() || oldChannel.members.size === 0) {
          await cleanupTempChannel(oldState.channelId);
        } else if (rec.ownerId === oldState.id) {
          await oldChannel.permissionOverwrites.delete(oldState.id, 'TempVoice owner left').catch(() => {});
          store.patchChannel(oldState.channelId, { ownerId: null });
          await syncTempText(oldChannel, store.getChannel(oldState.channelId));
          await updatePanel(oldState.channelId);
        }
      }
    }
  } catch (err) {
    console.error('voiceStateUpdate error:', err);
  }
});

client.on('interactionCreate', async interaction => {
  try {
    if (interaction.isChatInputCommand() && interaction.commandName === 'tempvoice') {
      const sub = interaction.options.getSubcommand();
      if (sub === 'setup') return handleSetup(interaction);
      if (sub === 'info') {
        const config = store.getGuild(interaction.guildId);
        return interaction.reply({
          content: config ? `Kategorie: <#${config.categoryId}>\nJoin-to-create: <#${config.lobbyId}>` : 'TempVoice ist noch nicht eingerichtet. Nutze `/tempvoice setup`.',
          flags: MessageFlags.Ephemeral,
        });
      }
    }

    if (interaction.isButton() && interaction.customId.startsWith('tv:')) return handleButton(interaction);
    if (interaction.isUserSelectMenu() && interaction.customId.startsWith('tv:')) return handleUserSelect(interaction);
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('tv:')) return handleStringSelect(interaction);
    if (interaction.isModalSubmit() && interaction.customId === 'tv:settings-modal') return handleSettingsModal(interaction);
  } catch (err) {
    console.error('interaction error:', err);
    const payload = { content: `❌ Fehler: ${err?.message || 'Unbekannter Fehler'}`, flags: MessageFlags.Ephemeral };
    if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(() => {});
    else await interaction.reply(payload).catch(() => {});
  }
});

client.login(TOKEN);
