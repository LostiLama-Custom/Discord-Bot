# Custom TempVoice Discord Bot

Join-to-create voice channels with an owner control panel in the voice channel's built-in text chat.

## Features

- Join a lobby voice channel -> a private managed voice channel is created and the user is moved into it.
- Owner-only control panel.
- Rename channel.
- User limit (0-99).
- Game + status, rendered into Discord's official voice-channel status.
- Bitrate control with server boost-limit validation.
- RTC/voice region selector, including automatic.
- NSFW toggle.
- Optional separate temporary text channel.
- Lock / unlock the voice channel.
- Hide / show the voice channel.
- Allow selected users.
- Deny selected users and disconnect them if they are currently inside.
- Transfer ownership while staying in the channel.
- If the owner leaves, ownership becomes claimable by any remaining member.
- If the channel becomes empty, the voice channel and its optional temp text channel are deleted.
- JSON persistence across restarts.

## Install

1. Install Node.js 22.12 or newer.
2. Copy `.env.example` to `.env`.
3. Put your bot token and application/client ID into `.env`.
4. Optional but recommended while testing: set `DEV_GUILD_ID` to your server ID.
5. Run:

```bash
npm install
npm start
```

## Discord Developer Portal

Enable / invite the bot with these permissions:

- View Channels
- Send Messages
- Read Message History
- Connect
- Move Members
- Manage Channels
- Manage Roles
- Set Voice Channel Status

Gateway intents needed by the code:

- Guilds
- Guild Voice States

No Message Content intent is required.

Invite scopes:

- `bot`
- `applications.commands`

## First setup

After the bot is online, run:

`/tempvoice setup`

The bot creates a category called `TEMP VOICE` and a lobby voice channel called `➕ Create Voice`.

Join that lobby. The bot creates your channel, moves you into it, and posts the control panel into the voice channel's built-in text chat.

## Notes

Discord does not expose a separate native "game" field for voice channels. This bot stores `game` separately and combines it with the channel status, e.g. `🎮 Minecraft • Chill Runde`.

The separate temporary text channel is optional. The control panel itself always lives in the voice channel's built-in text chat, so it keeps working even when the separate text channel is disabled.
